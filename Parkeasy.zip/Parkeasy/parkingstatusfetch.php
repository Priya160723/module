<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];

        require 'conn.php';
        // Establish the database connection
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "parkeasy";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        // Query to fetch parking data based on email
        $sql = "SELECT name, cost, floors, status, reason FROM parking WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $parkingData = [];

            while ($row = $result->fetch_assoc()) {
                $parking = [
                    'name' => $row['name'],
                    'cost' => $row['cost'],
                    'floors' => $row['floors'],
                    'status' => $row['status'],
                    'reason' => $row['reason']
                ];

                $imageName = $row['name'] . '.png';
                $filePath = 'parkingimage/' . $imageName;

                if (file_exists($filePath)) {
                    $imageData = file_get_contents($filePath);
                    $base64Image = base64_encode($imageData);
                    $parking['image'] = $base64Image;
                } else {
                    $parking['image'] = null;
                }

                $parkingData[] = $parking;
            }

            $response['status'] = 'success';
            $response['data'] = $parkingData;
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'No parking data found for the given email';
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Invalid input data';
    }

    echo json_encode($response);
}
?>
