<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'conn.php';
    // Establish the database connection
    // $servername = "localhost";
    // $username_db = "root";
    // $password_db = "";
    // $dbname = "parkeasy";

    // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }

    // Get the email from the POST request
    $input = json_decode(file_get_contents('php://input'), true);
    $email = $input['email'];

    if (!empty($email)) {
        // Prepare and bind the statement
        $stmt = $conn->prepare("SELECT email, name, cost, floors, status, plots FROM parking WHERE email = ?");
        $stmt->bind_param("s", $email);

        // Execute the statement
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $parkingData = [];

            while ($row = $result->fetch_assoc()) {
                $parking = [
                    'email' => $row['email'],
                    'name' => $row['name'],
                    'cost' => $row['cost'],
                    'plots' => $row['plots'],
                    'floors' => $row['floors'],
                    'status' => $row['status']
                ];

                $imageName = $row['name'] . '.png';
                $filePath = 'parkingimage/' . $imageName;

                if (file_exists($filePath)) {
                    $imageData = file_get_contents($filePath);
                    $base64Image = base64_encode($imageData);
                    $parking['image'] = $base64Image;
                } else {
                    $parking['image'] = null;
                }

                $parkingData[] = $parking;
            }

            $response['status'] = 'success';
            $response['data'] = $parkingData;
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'No parking data found for the specified email';
        }

        // Close the statement
        $stmt->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Email is required';
    }

    // Close the database connection
    $conn->close();

    echo json_encode($response);
} else {
    $response['status'] = 'failure';
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
}
