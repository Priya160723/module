<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($data["email"])) {
        $email = $data["email"];
        require 'conn.php';
        // Establish the database connection
        // $servername = "localhost";
        // $username_db = "root";
        // $password_db = "";
        // $dbname = "parkeasy";

        // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        // if ($conn->connect_error) {
        //     die("Connection failed: " . $conn->connect_error);
        // }

        $sql = "SELECT name, upiid, mobile FROM partner WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $response['status'] = 'success';
            $response['data'] = $row;

            // Check if the profile image exists
            $image_path = "profilepic/" . $email . ".png";
            if (file_exists($image_path)) {
                $response['data']['profile_image'] = base64_encode(file_get_contents($image_path));
            } else {
                $response['data']['profile_image'] = null;
            }
        } else {
            $response['status'] = 'failure';
            $response['message'] = 'No user found with this email';
        }

        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'Email not provided';
    }

    echo json_encode($response);
} else {
    $response['status'] = 'failure';
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
}
?>
