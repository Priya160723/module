<?php
header('Content-Type: application/json');

// Only process GET requests
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    require 'conn.php';
    // Database credentials
    // $servername = "localhost";
    // $username_db = "root";
    // $password_db = "";
    // $dbname = "parkeasy";

    // // Create connection
    // $conn = new mysqli($servername, $username_db, $password_db, $dbname);

    // // Check connection
    // if ($conn->connect_error) {
    //     die(json_encode([
    //         'status' => 'failure',
    //         'message' => 'Connection failed: ' . $conn->connect_error
    //     ]));
    // }

    // Fetch total number of emails in user table
    $userCountSql = "SELECT COUNT(email) as total_users FROM user";
    $userResult = $conn->query($userCountSql);
    if ($userResult->num_rows > 0) {
        $userCount = $userResult->fetch_assoc()['total_users'];
    } else {
        $userCount = 0;
    }

    // Fetch count of names in partner table where status is 'pending'
    $pendingCountSql = "SELECT COUNT(name) as pending_partners FROM parking WHERE status = 'pending'";
    $pendingResult = $conn->query($pendingCountSql);
    if ($pendingResult->num_rows > 0) {
        $pendingCount = $pendingResult->fetch_assoc()['pending_partners'];
    } else {
        $pendingCount = 0;
    }

    // Fetch total number of rows in partner table
    $partnerCountSql = "SELECT COUNT(*) as total_partners FROM partner";
    $partnerResult = $conn->query($partnerCountSql);
    if ($partnerResult->num_rows > 0) {
        $partnerCount = $partnerResult->fetch_assoc()['total_partners'];
    } else {
        $partnerCount = 0;
    }

    // Close connection
    $conn->close();

    // Prepare the response
    $response = [
        'status' => 'success',
        'data' => [
            'total_users' => $userCount,
            'pending_partners' => $pendingCount,
            'total_partners' => $partnerCount
        ]
    ];

    // Send the response in JSON format
    echo json_encode($response);
} else {
    // Send a response for non-GET requests
    echo json_encode([
        'status' => 'failure',
        'message' => 'Invalid request method. Please use GET.'
    ]);
}
