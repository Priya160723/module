<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode JSON data from the request body
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Extract data from JSON
    $parkingname = $data['parkingname'];
    $partneremail = $data['partneremail'];

    require 'conn.php';
    // Establish database connection
    // $servername = "localhost";
    // $username = "root";
    // $password = "";
    // $dbname = "parkeasy";

    // $conn = new mysqli($servername, $username, $password, $dbname);

    // if ($conn->connect_error) {
    //     die("Connection failed: " . $conn->connect_error);
    // }

    // Query to fetch all bookings matching partneremail and parkingname
    $sql = "SELECT id, parkingname, partneremail, useremail, total_cost, floor_no, slot_no, start, end ,status
            FROM booking 
            WHERE partneremail = ? AND parkingname = ? 
            ORDER BY id DESC";

    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters
    if (!$stmt->bind_param("ss", $partneremail, $parkingname)) {
        die('Binding parameters failed: ' . $stmt->error);
    }

    // Execute the statement
    if (!$stmt->execute()) {
        die('Execute failed: ' . $stmt->error);
    }

    // Bind result variables
    $stmt->bind_result($id, $parkingname, $partneremail, $useremail, $total_cost, $floor_no, $slot_no, $start, $end,$status);

    // Fetch all results
    $bookings = [];
    while ($stmt->fetch()) {
        $bookings[] = array(
            'id' => $id,
            'parkingname' => $parkingname,
            'partneremail' => $partneremail,
            'useremail' => $useremail,
            'total_cost' => $total_cost,
            'floor_no' => $floor_no,
            'slot_no' => $slot_no,
            'start' => $start, // Assuming start is already in DATETIME format from database
            'end' => $end   ,   // Assuming end is already in DATETIME format from database
            'status'=>$status
        );
    }

    // Prepare response
    if (!empty($bookings)) {
        $response['status'] = 'success';
        $response['data'] = $bookings;
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'No bookings found matching criteria';
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Send JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo json_encode(array("status" => "failure", "message" => "Method Not Allowed"));
}

?>
