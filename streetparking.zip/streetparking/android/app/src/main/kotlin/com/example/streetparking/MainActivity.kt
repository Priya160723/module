package com.example.streetparking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
