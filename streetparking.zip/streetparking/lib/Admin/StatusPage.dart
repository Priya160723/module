import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../urls.dart';

class StatusPage extends StatefulWidget {
  const StatusPage({Key? key}) : super(key: key);

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> {
  List<Map<String, dynamic>> parkingData = [];

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    try {
      final response = await http.post(
        Uri.parse('${Urls.ip}/Parkeasy/adminstatuspage.php'),
        body: jsonEncode({}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          setState(() {
            parkingData = List<Map<String, dynamic>>.from(data['data']);
          });
          print('Fetched parking data successfully: $parkingData');
        } else {
          print('Failed to fetch parking status: ${data['message']}');
        }
      } else {
        print('Error fetching parking status: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception occurred while fetching parking status: $e');
    }
  }

  Future<void> changeParkingStatus(String action, String name, String email, {String? reason}) async {
    try {
      final response = await http.post(
        Uri.parse('${Urls.ip}/Parkeasy/adminstatuschanging.php'),
        body: jsonEncode({
          'action': action,
          'name': name,
          'email': email,
          'reason': reason,
        }),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('Response after changing status: $data');
        // Refresh the parking status list after the action
        fetchParkingStatus();
      } else {
        print('Error changing parking status: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception occurred while changing parking status: $e');
    }
  }

  Future<void> showRejectDialog(String name, String email) async {
    TextEditingController reasonController = TextEditingController();

    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Reject Parking Request'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Please provide a reason for rejection:'),
                TextField(
                  controller: reasonController,
                  decoration: InputDecoration(hintText: 'Reason'),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Submit'),
              onPressed: () {
                changeParkingStatus('reject', name, email, reason: reasonController.text);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final pendingParkingData = parkingData.where((parking) => parking['status'] == 'pending').toList();

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: fetchParkingStatus,
        child: pendingParkingData.isEmpty
            ? Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.check_circle, size: 100, color: Colors.green),
              SizedBox(height: 20),
              Text(
                'No pending approvals or rejections',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        )
            : ListView.builder(
          itemCount: pendingParkingData.length,
          itemBuilder: (context, index) {
            final parking = pendingParkingData[index];
            final imageBytes = base64Decode(parking['image']);

            return SlideTransition(
              position: Tween<Offset>(
                begin: Offset(0, -1),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: ModalRoute.of(context)!.animation!,
                curve: Curves.easeInOut,
              )),
              child: Container(
                margin: const EdgeInsets.symmetric(vertical: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      height: 200,
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: MemoryImage(imageBytes),
                          fit: BoxFit.cover,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      parking['name'],
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                    ),
                    SizedBox(height: 5),
                    Text('Cost: ${parking['cost']}'),
                    Text('Floors: ${parking['floors']}'),
                    SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.green,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                            ),
                          ),
                          onPressed: () {
                            final name = parking['name'];
                            final email = parking['email'];
                            changeParkingStatus('approve', name, email, reason: null);
                          },
                          child: Text('Accept', style: TextStyle(color: Colors.white)),
                        ),
                        SizedBox(width: 10),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: Colors.red,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                            ),
                          ),
                          onPressed: () {
                            final name = parking['name'];
                            final email = parking['email'];
                            showRejectDialog(name, email);
                          },
                          child: Text('Reject', style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
