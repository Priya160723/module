import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import '../Colors.dart'; // Assuming you have an AppColors class for colors
import '../urls.dart'; // Adjust the import based on your project structure

class PartnerEditProfile extends StatefulWidget {
  final String email;
  const PartnerEditProfile({Key? key, required this.email}) : super(key: key);

  @override
  State<PartnerEditProfile> createState() => _PartnerEditProfileState();
}

class _PartnerEditProfileState extends State<PartnerEditProfile> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController upiidController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  File? _image;
  final picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
    emailController.text = widget.email;
  }

  Future<void> fetchUserDetails() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/partnergeteditprofile.php'),
      body: jsonEncode({
        'email': widget.email,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        final userData = data['data'];
        setState(() {
          nameController.text = userData['name'];
          upiidController.text = userData['upiid'];
          mobileController.text = userData['mobile'];
          _image = userData['profile_image'];

        });
      } else {
        // Handle failure
        print('Failed to fetch user details: ${data['message']}');
      }
    } else {
      // Handle the error
      print('Error fetching user details');
    }
  }

  Future<void> pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> saveProfile() async {
    String base64Image = '';
    if (_image != null) {
      base64Image = base64Encode(_image!.readAsBytesSync());
    }

    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/partnerupdateprofile.php'),
      body: jsonEncode({
        'email': widget.email,
        'name': nameController.text,
        'upiid': upiidController.text,
        'mobile': mobileController.text,
        'profile_image': base64Image,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        // Handle success
        ScaffoldMessenger.of(context).showSnackBar(

          SnackBar(content: Text('Profile updated successfully')),
        );
      } else {
        // Handle failure
        ScaffoldMessenger.of(context).showSnackBar(

          SnackBar(content: Text('Failed to update profile: ${data['message']}')),
        );
      }
    } else {
      // Handle server error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Server error: ${response.statusCode}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Edit Profile',style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue[100],
        iconTheme: IconThemeData(
          color: Colors.white
        ),
      ),
      body: RefreshIndicator(
        onRefresh: fetchUserDetails,
        child: Container(

          height: double.infinity, // Fill the entire screen height
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                GestureDetector(
                  onTap: pickImage,
                  child: CircleAvatar(
                    radius: 60,
                    backgroundImage: _image != null ? FileImage(_image!) : null,
                    child: _image == null ? Icon(Icons.add_a_photo) : null,
                  ),
                ),
                SizedBox(height: 20),
                Text('Your Information',style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                SizedBox(height: 20),
                buildTextField(nameController, 'Name'),
                SizedBox(height: 20),
                buildTextField(emailController, 'Email', readOnly: true),
                SizedBox(height: 20),
                buildTextField(upiidController, 'UPI ID'),
                SizedBox(height: 20),
                buildTextField(mobileController, 'Mobile', keyboardType: TextInputType.number),
                SizedBox(height: 20),
                Container(
                  width: 250,
                  child: ElevatedButton(
                    onPressed: saveProfile,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[500],
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 15),
                    ),
                    child: Text(
                      'Update',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(TextEditingController controller, String labelText,
      {bool readOnly = false, TextInputType keyboardType = TextInputType.text}) {
    return TextField(
      controller: controller,
      readOnly: readOnly,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        labelText: labelText,
        labelStyle: TextStyle(color: Colors.black),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      style: TextStyle(color: Colors.black),
    );
  }
}
