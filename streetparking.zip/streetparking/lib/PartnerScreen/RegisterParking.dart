import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:streetparking/Colors.dart';
import '../urls.dart';

class RegisterParking extends StatefulWidget {
  final String email;
  const RegisterParking({Key? key, required this.email}) : super(key: key);

  @override
  State<RegisterParking> createState() => _RegisterParkingState();
}

class _RegisterParkingState extends State<RegisterParking> {
  int selectedFloors = 1;
  List<int> plotNumbers = List<int>.filled(12, 0); // Initialize with 12 zeros
  String costPerHour = '';
  String locationname = '';
  String parkingAreaName = '';
  File? _image;
  final picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[100],
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
        centerTitle: true,
        title: Text(
          'Register Parking',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Card(
                color: Colors.white,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Parking Area Name',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      TextField(
                        onChanged: (value) {
                          parkingAreaName = value;
                        },
                        decoration: InputDecoration(
                          hintText: 'Enter Parking Area Name',
                          hintStyle: TextStyle(color: Colors.black),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Number of Floors',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      DropdownButton<int>(
                        value: selectedFloors,
                        onChanged: (value) {
                          setState(() {
                            selectedFloors = value!;
                            plotNumbers = List<int>.filled(selectedFloors, 0); // Reset plotNumbers to match selectedFloors
                          });
                        },
                        items: List.generate(
                          12,
                              (index) => DropdownMenuItem<int>(
                            value: index + 1,
                            child: Text('${index + 1}', style: TextStyle(color: Colors.black)),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Cost per Hour',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      TextField(
                        onChanged: (value) {
                          costPerHour = value;
                        },
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: 'Enter cost per hour',
                          hintStyle: TextStyle(color: Colors.black),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Location',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                      TextField(
                        onChanged: (value) {
                          locationname = value;
                        },

                        decoration: InputDecoration(
                          hintText: 'Enter Location',
                          hintStyle: TextStyle(color: Colors.black),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Plot Numbers',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Container(
                height: 200.0, // Adjust the height as needed
                child: ListView.builder(
                  itemCount: selectedFloors,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        title: Text('Floor ${index + 1}'),
                        subtitle: TextField(
                          onChanged: (value) {
                            setState(() {
                              plotNumbers[index] = int.parse(value);
                            });
                          },
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            hintText: 'Enter plot number',
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: Text(
                  'Upload Parking image',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: GestureDetector(
                  onTap: () {
                    _getImage();
                  },
                  child: Container(
                    height: 100,
                    width: 100,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: _image != null
                        ? Image.file(_image!, fit: BoxFit.cover)
                        : Icon(Icons.upload_file, size: 50, color: Colors.grey),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: Container(
                  width: 250,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[500],
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () {
                      if (_image != null) {
                        registerParking();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Please upload a parking image.'),
                        ));
                      }
                    },
                    child: Text('Register Parking'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> registerParking() async {
    try {
      // Convert image file to base64
      List<int> imageBytes = await _image!.readAsBytes();
      String base64Image = base64Encode(imageBytes);

      // Send data to PHP endpoint
      final response = await http.post(
        Uri.parse('${Urls.ip}/Parkeasy/parkingregister.php'), // Replace with your PHP endpoint URL
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          'email': widget.email,
          'name': parkingAreaName,
          'floors': selectedFloors,
          'plots': plotNumbers.sublist(0, selectedFloors), // Only send the relevant plot numbers
          'cost': costPerHour,
          'image': base64Image,
          'location':locationname
        }),
      );

      // Handle response
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          // Handle success
          Navigator.pop(context);
          print('Parking area registered successfully');
        } else {
          // Handle failure
          print('Failed to register parking area: ${data['message']}');
        }
      } else {
        // Handle server error
        print('Server error: ${response.statusCode}');
      }
    } catch (e) {
      // Handle exception
      print('Error: $e');
    }
  }
}
