import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:streetparking/urls.dart';

class Booking {
  final String id;
  final String parkingName;
  final String partnerEmail;
  final String userEmail;
  final String totalCost;
  final String floorNo;
  final String slotNo;
  final String start;
  final String end;
  final String status;
  final String profilePic;

  Booking({
    required this.id,
    required this.parkingName,
    required this.partnerEmail,
    required this.userEmail,
    required this.totalCost,
    required this.floorNo,
    required this.slotNo,
    required this.start,
    required this.end,
    required this.status,
    required this.profilePic,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: json['id'].toString(),
      parkingName: json['parkingname'].toString(),
      partnerEmail: json['partneremail'].toString(),
      userEmail: json['useremail'].toString(),
      totalCost: json['total_cost'].toString(),
      floorNo: json['floor_no'].toString(),
      slotNo: json['slot_no'].toString(),
      start: json['start'].toString(),
      end: json['end'].toString(),
      status: json['status'].toString(),
      profilePic: json['profilepic'] != null ? json['profilepic'].toString() : '',
    );
  }
}

class StatusPage extends StatefulWidget {
  final String email;
  const StatusPage({Key? key, required this.email}) : super(key: key);

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> with SingleTickerProviderStateMixin {
  late Future<List<Booking>> futureAcceptedBookings;
  late Future<List<Booking>> futureRejectedBookings;
  late Future<List<Booking>> futurePendingBookings;

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    futureAcceptedBookings = fetchBookings('approved');
    futureRejectedBookings = fetchBookings('rejected');
    futurePendingBookings = fetchBookings('pending');
    _tabController = TabController(length: 3, vsync: this);
  }

  Future<List<Booking>> fetchBookings(String status) async {
    try {
      final url = Uri.parse('${Urls.ip}/Parkeasy/partnerpendinghome.php');
      final response = await http.post(
        url,
        body: json.encode({'partneremail': widget.email}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse['status'] == 'success') {
          List<dynamic> data = jsonResponse['data'];
          List<Booking> bookings = data
              .map((json) => Booking.fromJson(json))
              .where((booking) => booking.status == status)
              .toList();

          return bookings;
        } else {
          throw Exception('Failed to load bookings: ${jsonResponse['message']}');
        }
      } else {
        throw Exception('Failed to load bookings: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching bookings: $e');
      throw Exception('Error fetching bookings: $e');
    }
  }

  Future<void> updateBookingStatus(String bookingId, String newStatus) async {
    try {
      final url = Uri.parse('${Urls.ip}/Parkeasy/partnerhome.php');
      final response = await http.post(
        url,
        body: json.encode({
          'booking_id': bookingId,
          'new_status': newStatus,
        }),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);
        if (jsonResponse['status'] == 'success') {
          // Refresh the bookings list
          setState(() {
            futureAcceptedBookings = fetchBookings('approved');
            futureRejectedBookings = fetchBookings('rejected');
            futurePendingBookings = fetchBookings('pending');
          });
        } else {
          throw Exception('Failed to update booking status: ${jsonResponse['message']}');
        }
      } else {
        throw Exception('Failed to update booking status: ${response.statusCode}');
      }
    } catch (e) {
      print('Error updating booking status: $e');
      throw Exception('Error updating booking status: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          bottom: TabBar(
            controller: _tabController,
            tabs: [
              Tab(text: 'Accepted'),
              Tab(text: 'Rejected'),
              Tab(text: 'Pending'),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            buildBookingList(futureAcceptedBookings, false),
            buildBookingList(futureRejectedBookings, false),
            buildBookingList(futurePendingBookings, true),
          ],
        ),
      ),
    );
  }

  Widget buildBookingList(Future<List<Booking>> futureBookings, bool showActions) {
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          futureAcceptedBookings = fetchBookings('approved');
          futureRejectedBookings = fetchBookings('rejected');
          futurePendingBookings = fetchBookings('pending');
        });
      },
      child: FutureBuilder<List<Booking>>(
        future: futureBookings,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No bookings found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final booking = snapshot.data![index];
                return Card(
                  margin: EdgeInsets.all(10),
                  elevation: 5,
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              radius: 30,
                              backgroundImage: booking.profilePic.isNotEmpty
                                  ? MemoryImage(base64Decode(booking.profilePic))
                                  : null,
                              child: booking.profilePic.isEmpty
                                  ? Icon(Icons.person, size: 30)
                                  : null,
                            ),
                            SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  booking.userEmail,
                                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  'Parking Name: ${booking.parkingName}',
                                  style: TextStyle(fontSize: 15),
                                ),
                              ],
                            ),
                            Spacer(),
                            if (showActions)
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      updateBookingStatus(booking.id, 'approved');
                                    },
                                    child: Icon(
                                      Icons.check,
                                      color: Colors.green,
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  GestureDetector(
                                    onTap: () {
                                      updateBookingStatus(booking.id, 'rejected');
                                    },
                                    child: Icon(
                                      Icons.close,
                                      color: Colors.red,
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Text('Plot No: ${booking.slotNo}, Floor No: ${booking.floorNo}'),
                        Text('Start: ${booking.start}'),
                        Text('End: ${booking.end}'),
                        Text(
                          'Status: ${booking.status}',
                          style: TextStyle(color: booking.status == 'rejected' ? Colors.red : Colors.green),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
