import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:animations/animations.dart';
import 'package:streetparking/urls.dart';

class StatusPage extends StatefulWidget {
  final String email;
  const StatusPage({Key? key, required this.email}) : super(key: key);

  @override
  State<StatusPage> createState() => _StatusPageState();
}

class _StatusPageState extends State<StatusPage> {
  late Future<List<Map<String, dynamic>>> _bookings;

  @override
  void initState() {
    super.initState();
    _bookings = fetchBookings();
  }

  Future<List<Map<String, dynamic>>> fetchBookings() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/userstatus.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': widget.email}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        return List<Map<String, dynamic>>.from(data['data']);
      } else {
        throw Exception('Failed to load bookings');
      }
    } else {
      throw Exception('Failed to load bookings');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _bookings,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.info, size: 80, color: Colors.grey),
                  SizedBox(height: 10),
                  Text(
                    'No bookings pending for approval or rejection',
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            );
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length > 5 ? 5 : snapshot.data!.length,
              itemBuilder: (context, index) {
                final booking = snapshot.data![index];
                final imageBytes = base64Decode(booking['profilepic'] ?? '');

                return OpenContainer(
                  closedBuilder: (context, action) => Card(
                    margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 5,
                    child: ListTile(
                      contentPadding: EdgeInsets.all(10),
                      leading: CircleAvatar(
                        backgroundImage: MemoryImage(imageBytes),
                        radius: 30,
                      ),
                      title: Text(
                        booking['parkingname'],
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 5),
                          Text('Floor: ${booking['floor_no']} - Slot: ${booking['slot_no']}'),
                          SizedBox(height: 5),
                          Text('Cost: ${booking['total_cost']}'),
                          SizedBox(height: 5),
                          Text('Start: ${booking['start']}'),
                          SizedBox(height: 5),
                          Text('End: ${booking['end']}'),
                          SizedBox(height: 10),
                          StatusBadge(status: booking['status']),
                        ],
                      ),
                    ),
                  ),
                  openBuilder: (context, action) => BookingDetailsPage(booking: booking),
                  transitionDuration: Duration(milliseconds: 500),
                  transitionType: ContainerTransitionType.fadeThrough,
                );
              },
            );
          }
        },
      ),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String status;

  const StatusBadge({Key? key, required this.status}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color color;
    String text;

    switch (status) {
      case 'approved':
        color = Colors.green;
        text = 'Accepted';
        break;
      case 'rejected':
        color = Colors.red;
        text = 'Rejected';
        break;
      case 'pending':
      default:
        color = Colors.orange;
        text = 'Pending';
        break;
    }

    return Container(
      padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class BookingDetailsPage extends StatelessWidget {
  final Map<String, dynamic> booking;

  const BookingDetailsPage({Key? key, required this.booking}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final imageBytes = base64Decode(booking['profilepic'] ?? '');

    return Scaffold(
      appBar: AppBar(
        title: Text('Booking Details'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            CircleAvatar(
              backgroundImage: MemoryImage(imageBytes),
              radius: 50,
            ),
            SizedBox(height: 20),
            Text(
              'Parking Name: ${booking['parkingname']}',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('Floor: ${booking['floor_no']}'),
            Text('Slot: ${booking['slot_no']}'),
            Text('Cost: ${booking['total_cost']}'),
            Text('Start: ${booking['start']}'),
            Text('End: ${booking['end']}'),
            Text('Status: ${booking['status']}'),
            SizedBox(height: 20),
            StatusBadge(status: booking['status']),
          ],
        ),
      ),
    );
  }
}
