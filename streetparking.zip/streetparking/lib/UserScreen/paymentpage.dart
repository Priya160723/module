import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:streetparking/UserScreen/homescreen.dart';
import 'dart:convert';


import '../urls.dart';

class PaymentPage extends StatefulWidget {
  final String email;
  final Map<String, dynamic> bookingData;

  const PaymentPage({Key? key, required this.email, required this.bookingData}) : super(key: key);

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  late Razorpay _razorpay;
  final _amountController = TextEditingController();
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _amountController.text=widget.bookingData['total_cost'];
    _nameController.text=widget.email;
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    _amountController.dispose();
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  void _showWarningDialog() {
    showDialog<void>(
      context: context,
      barrierDismissible: false, // Prevents dismissal by tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Warning'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Money once paid is not refundable.'),
                SizedBox(height: 16),
                Text('Do you want to proceed with the payment?'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
              },
            ),
            TextButton(
              child: Text('Proceed'),
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                _startPayment(); // Call the payment function
              },
            ),
          ],
        );
      },
    );
  }
  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    String transactionId = response.paymentId!;
    final data = {
      "email": widget.email,
      "parkingname": widget.bookingData['parkingname'],
      "partneremail": widget.bookingData['partneremail'],
      "useremail": widget.email,
      "total_cost": widget.bookingData['total_cost'],
      "floor_no": widget.bookingData['floor_no'],
      "slot_no": widget.bookingData['slot_no'],
      "start": widget.bookingData['start'],
      "end": widget.bookingData['end'],
      "payment_status": "success",
      "transaction_id": transactionId,
    };

    final url = '${Urls.ip}/Parkeasy/bookingslots.php';

    try {
      final serverResponse = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode(data),
      );

      if (serverResponse.statusCode == 200) {
        // Check if the response is JSON
        if (serverResponse.headers['content-type']?.contains('application/json') ?? false) {
          final responseData = json.decode(serverResponse.body);
          if (responseData is Map<String, dynamic> && responseData['status'] == 'success') {
            _showResultDialog('Payment Successful\n\nTransaction ID: $transactionId');

          } else {
            _showResultDialog('Payment Successful, but failed to update booking status');

          }
        } else {
          _showResultDialog('Unexpected response format from server');
        }
      } else {
        _showResultDialog('Server error: ${serverResponse.statusCode}');
      }
    } catch (e) {
      _showResultDialog('Error occurred while updating booking status');
      print('Error: $e');
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) async {
    final data = {
      "email": widget.email,
      "parkingname": widget.bookingData['parkingname'],
      "partneremail": widget.bookingData['partneremail'],
      "useremail": widget.email,
      "total_cost": widget.bookingData['total_cost'],
      "floor_no": widget.bookingData['floor_no'],
      "slot_no": widget.bookingData['slot_no'],
      "start": widget.bookingData['start'],
      "end": widget.bookingData['end'],
      "payment_status": "failed",
      "transaction_id": "N/A",
    };

    final url = '${Urls.ip}/Parkeasy/bookingslots.php';

    try {
      final serverResponse = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode(data),
      );

      if (serverResponse.statusCode == 200) {
        if (serverResponse.headers['content-type']?.contains('application/json') ?? false) {
          final responseData = json.decode(serverResponse.body);
          if (responseData is Map<String, dynamic> && responseData['status'] == 'success') {
            _showResultDialog('Payment Failed\n\nError: ${response.message}');
          } else {
            _showResultDialog('Payment Failed, but failed to update booking status');
          }
        } else {
          _showResultDialog('Unexpected response format from server');
        }
      } else {
        _showResultDialog('Server error: ${serverResponse.statusCode}');
      }
    } catch (e) {
      _showResultDialog('Error occurred while updating booking status: $e');
      print('Error: $e');
    }
  }


  void _handleExternalWallet(ExternalWalletResponse response) {
    _showResultDialog('External Wallet\n\nWallet: ${response.walletName}');
  }

  void _showResultDialog(String message) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Payment Result'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text(message),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UserHomeScreen(

                      email: widget.email, name: '',
                    ),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  void _startPayment() {
    final amount = int.tryParse(_amountController.text) ?? 0;
    if (amount <= 0) {
      _showResultDialog('Please enter a valid amount');
      return;
    }

    var options = {
      'key': 'rzp_test_FF1W8PS1WXXDVN', // Replace with your Razorpay API key
      'amount': amount * 100, // Amount in paise (1 INR = 100 paise)
      'name': _nameController.text,
      'description': _descriptionController.text,
      'prefill': {
        'contact': '7305891254', // Replace with actual contact number if needed
        'email': widget.email,
      },
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print('Error opening Razorpay: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[100],
        centerTitle: true,
        title: Text(" Payment", style: TextStyle(color: Colors.white)),
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Enter Payment Details',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Bank HolderName',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                labelText: 'Description',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.description),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _amountController,
              decoration: InputDecoration(
                labelText: 'Amount (INR)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.monetization_on),
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 40),
            Container(
              width: 250,
              child: ElevatedButton(
                //onPressed: _startPayment,
                onPressed: _showWarningDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[500],
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                child: Text(
                  "Pay",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
