import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:streetparking/Colors.dart';
import 'package:http/http.dart' as http;
import 'package:streetparking/UserScreen/paymentpage.dart';
import 'dart:convert';

import 'package:streetparking/urls.dart';


import 'homescreen.dart';

class Booking extends StatefulWidget {
  final Map<String, dynamic> parking;
  final String email;

  const Booking({Key? key, required this.parking, required this.email}) : super(key: key);

  @override
  State<Booking> createState() => _BookingState();
}

class _BookingState extends State<Booking> {
  DateTime? _fromDate;
  DateTime? _toDate;
  TimeOfDay? _fromTime;
  TimeOfDay? _toTime;



  Future<void> _selectDate(BuildContext context, bool isFrom) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      setState(() {
        if (isFrom) {
          _fromDate = picked;
        } else {
          _toDate = picked;
        }
      });
    }
  }
  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Booking Status"),
          content: Text("Successfully booked"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => UserHomeScreen(email: widget.email, name: '',

                    ),
                  ),
                );

              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }

  Future<void> _selectTime(BuildContext context, bool isFrom) async {
    final now = TimeOfDay.now();
    TimeOfDay initialTime = isFrom ? now : (_fromTime ?? now);

    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: initialTime,
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light().copyWith(primary: Colors.blue),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        if (isFrom) {
          _fromTime = picked;
          if (_toTime != null) {
            final fromDateTime = DateTime(1, 1, 1, _fromTime!.hour, _fromTime!.minute);
            final toDateTime = DateTime(1, 1, 1, _toTime!.hour, _toTime!.minute);
            if (toDateTime.isBefore(fromDateTime)) {
              _toTime = _fromTime;
            }
          }
        } else {
          _toTime = picked;
        }
      });
    }
  }

  double calculateDurationInHours() {
    if (_fromDate != null && _toDate != null && _fromTime != null && _toTime != null) {
      final fromDateTime = DateTime(
        _fromDate!.year,
        _fromDate!.month,
        _fromDate!.day,
        _fromTime!.hour,
        _fromTime!.minute,
      );
      final toDateTime = DateTime(
        _toDate!.year,
        _toDate!.month,
        _toDate!.day,
        _toTime!.hour,
        _toTime!.minute,
      );
      return toDateTime.difference(fromDateTime).inHours.toDouble();
    }
    return 0;
  }

  Future<void> _sendBookingRequest() async {
    if (_fromDate != null && _toDate != null && _fromTime != null && _toTime != null) {
      final fromDateTime = DateTime(
        _fromDate!.year,
        _fromDate!.month,
        _fromDate!.day,
        _fromTime!.hour,
        _fromTime!.minute,
      ).toIso8601String();
      final toDateTime = DateTime(
        _toDate!.year,
        _toDate!.month,
        _toDate!.day,
        _toTime!.hour,
        _toTime!.minute,
      ).toIso8601String();

      final data = {
        "parkingname": widget.parking['name'],
        "partneremail": widget.parking['email'],
        "useremail": widget.email,
        "total_cost": (calculateDurationInHours() * double.parse(widget.parking['cost'])).toStringAsFixed(2),
        "floor_no": widget.parking['floor_no'],
        "slot_no": widget.parking['slot_no'],
        "start": fromDateTime,
        "end": toDateTime
      };

      final url = '${Urls.ip}/Parkeasy/bookingslots.php';
      final response = await http.post(
        Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode(data),
      );

      if (response.statusCode == 200) {
        // Handle success response
        _showSuccessDialog(context);
        final responseData = json.decode(response.body);
       print(responseData);
      } else {
        // Handle error response
        print('Failed to send booking request');
      }
    } else {
      // Handle invalid input
      print('Please select valid dates and times');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[100],
        title: Text('Booking ${widget.parking['name']}', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(height: 10),Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.blue[400],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text('Select Date', style: TextStyle(color: Colors.white, fontSize: 18)),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text('From'),
                    Text('To'),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  _dateContainer(context, 'From', true),
                  _dateContainer(context, 'To', false),
                ],
              ),
              SizedBox(height: 50),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.blue[400],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text('Select Time', style: TextStyle(color: Colors.white, fontSize: 18)),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text('From'),
                    Text('To'),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  _timeContainer(context, 'From', true),
                  _timeContainer(context, 'To', false),
                ],
              ),
              SizedBox(height: 50),
              Center(
                child: Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 2,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Duration: ${calculateDurationInHours()} hours'),
                      SizedBox(height: 10),
                      Text('Amount: ${(calculateDurationInHours() * double.parse(widget.parking['cost'])).toStringAsFixed(0)} rs'),
                    ],
                  ),
                ),
              ),


              SizedBox(height: 25,),
              Center(
                child: Container(
                  width: 250,
                  height: 60,
                  child: ElevatedButton(
                    onPressed: () {
                      final bookingData = {
                        "parkingname": widget.parking['name'],
                        "partneremail": widget.parking['email'],
                        "useremail": widget.email,
                        "total_cost": (calculateDurationInHours() * double.parse(widget.parking['cost'])).toStringAsFixed(0),
                        "floor_no": widget.parking['floor_no'],
                        "slot_no": widget.parking['slot_no'],
                        "start": DateTime(
                          _fromDate!.year,
                          _fromDate!.month,
                          _fromDate!.day,
                          _fromTime!.hour,
                          _fromTime!.minute,
                        ).toIso8601String(),
                        "end": DateTime(
                          _toDate!.year,
                          _toDate!.month,
                          _toDate!.day,
                          _toTime!.hour,
                          _toTime!.minute,
                        ).toIso8601String(),
                      };

                      print('Navigating to PaymentPage with data: $bookingData'); // Debug statement

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PaymentPage(
                            email: widget.email,
                            bookingData: bookingData,
                          ),
                        ),
                      ).then((_) {
                        // You can also check if there's any result returned from PaymentPage
                        print('Returned from PaymentPage');
                      });
                    },
                    child: Text('Pay', style: TextStyle(color: Colors.white, fontSize: 18)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      padding: EdgeInsets.symmetric(horizontal: 80, vertical: 20),
                    ),
                  ),
                ),
              ),

              SizedBox(height: 25,),
              // Center(
              //   child: Container(
              //     height: 60,
              //     width: 250,
              //     child: ElevatedButton(
              //       onPressed: _sendBookingRequest,
              //       child: Text('Request', style: TextStyle(color: Colors.white, fontSize: 18)),
              //       style: ElevatedButton.styleFrom(
              //         backgroundColor: Colors.blueAccent,
              //         padding: EdgeInsets.symmetric(horizontal: 80, vertical: 20),
              //       ),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _dateContainer(BuildContext context, String label, bool isFrom) {
    return GestureDetector(
      onTap: () => _selectDate(context, isFrom),
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: <Widget>[
            Icon(Icons.calendar_today),
            SizedBox(width: 10),
            Text(
              isFrom && _fromDate != null
                  ? DateFormat('yyyy-MM-dd').format(_fromDate!)
                  : !isFrom && _toDate != null
                  ? DateFormat('yyyy-MM-dd').format(_toDate!)
                  : 'Select date',
            ),
          ],
        ),
      ),
    );
  }

  Widget _timeContainer(BuildContext context, String label, bool isFrom) {
    final now = TimeOfDay.now();
    TimeOfDay initialTime = isFrom ? now : (_fromTime ?? now);

    return GestureDetector(
      onTap: () => _selectTime(context, isFrom),
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: <Widget>[
            Icon(Icons.access_time),
            SizedBox(width: 10),
            Text(
              isFrom && _fromTime != null
                  ? _fromTime!.format(context)
                  : !isFrom && _toTime != null
                  ? _toTime!.format(context)
                  : 'Select time',
            ),
          ],
        ),
      ),
    );
  }
}
