import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:streetparking/Colors.dart';
import 'dart:convert';

import '../urls.dart'; // Ensure you have a urls.dart file with the base URL or IP defined

class Payment {
  final String parkingName;
  final String totalCost;
  final String paymentStatus;
  final String transactionId;

  Payment({
    required this.parkingName,
    required this.totalCost,
    required this.paymentStatus,
    required this.transactionId,
  });

  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      parkingName: json['parkingname'].toString(),
      totalCost: json['total_cost'].toString(),
      paymentStatus: json['payment_status'].toString(),
      transactionId: json['transactionid'].toString(),
    );
  }
}

class PaymentHistory extends StatefulWidget {
  final String email;
  const PaymentHistory({Key? key, required this.email}) : super(key: key);

  @override
  State<PaymentHistory> createState() => _PaymentHistoryState();
}

class _PaymentHistoryState extends State<PaymentHistory> {
  late Future<List<Payment>> futurePayments;

  @override
  void initState() {
    super.initState();
    futurePayments = fetchPayments();
  }

  Future<List<Payment>> fetchPayments() async {
    final url = Uri.parse('${Urls.ip}/Parkeasy/payment_history.php');
    final response = await http.post(
      url,
      body: json.encode({'email': widget.email}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final jsonResponse = json.decode(response.body);
      if (jsonResponse['status'] == 'success') {
        List<dynamic> data = jsonResponse['data'];
        return data.map((json) => Payment.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load payments');
      }
    } else {
      throw Exception('Failed to load payments');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment History'),
        centerTitle: true,
        foregroundColor: Colors.white,
        backgroundColor: AppColors.backgroundColor,
      ),
      body: FutureBuilder<List<Payment>>(
        future: futurePayments,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No payments found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                final payment = snapshot.data![index];
                final firstLetter = payment.parkingName.isNotEmpty
                    ? payment.parkingName[0].toUpperCase()
                    : '';

                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  elevation: 5,
                  child: ListTile(
                    contentPadding: EdgeInsets.all(15),
                    leading: CircleAvatar(
                      backgroundColor: Colors.blueAccent,
                      radius: 30,
                      child: Text(
                        firstLetter,
                        style: TextStyle(
                          fontSize: 26,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    title: Text(
                      //payment.parkingName
                      'Rs ${payment.totalCost} ',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 5),
                        // Text('Total Cost: Rs ${payment.totalCost} ',
                        //     style: TextStyle(fontSize: 16)),
                        Text('Transaction ID: ${payment.transactionId}',
                            style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    trailing: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        backgroundColor: payment.paymentStatus == 'Pending'
                            ? Colors.orange
                            : payment.paymentStatus == 'failed'
                            ? Colors.red
                            : Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                      child: Text(
                        payment.paymentStatus,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),

                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
