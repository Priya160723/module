import 'dart:convert';


import 'package:flutter/material.dart';
import 'package:streetparking/UserScreen/usereditprofile.dart';
import 'package:streetparking/UserScreen/userhomescreen.dart';
import 'package:http/http.dart' as http;
import 'package:streetparking/UserScreen/userprofile.dart';
import 'package:streetparking/contactus.dart';
import '../Colors.dart';
import '../LoginOptions.dart';
import '../UserScreen/historypage.dart';
import '../UserScreen/statuspage.dart';
import '../feedbackpage.dart';
import '../urls.dart';
import 'BookingHistory.dart';
import 'PaymentHistory.dart';



class UserHomeScreen extends StatefulWidget {
  final String email;
  final String name;
  const UserHomeScreen({Key? key, required this.email, required this.name}) : super(key: key);

  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  int _selectedIndex = 0;




  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  void initState() {

    super.initState();
    fetchUserDetails();
  }
  String namee="";
  String base64image="";
  Future<void> fetchUserDetails() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/usergeteditprofile.php'),
      body: jsonEncode({
        'email': widget.email,
      }),
      headers: {
        'Content-Type': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        final userData = data['data'];
        setState(() {
          namee = userData['name'];
          print(namee+"cdsccsdss");
          print(userData['profile_image']);

          base64image = userData['profile_image'];
          print(base64image);
        });
      } else {
        // Handle failure
        print('Failed to fetch user details: ${data['message']}');
      }
    } else {
      // Handle the error
      print('Error fetching user details');
    }
  }

  @override
  Widget build(BuildContext context) {
     final List<Widget> _widgetOptions = <Widget>[
      userhomescreen(email: widget.email,),
      StatusPage(email:widget.email),
      HistoryPage(),
    ];
    return RefreshIndicator(
      onRefresh: fetchUserDetails,
      child: Scaffold(
        backgroundColor: Colors.blue[100],
        appBar: AppBar(
          centerTitle: true,
          title: Text('User Home',style: TextStyle(color: Colors.white),),
          backgroundColor: Colors.blue[100],


          iconTheme: IconThemeData(
            color: Colors.white
          ),



          leading: Builder(
            builder: (context) => IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
        ),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: Container(
            color: Colors.blue[100],
            child: ListView(
              children: [
                DrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.blue[100],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.white,
                        backgroundImage: base64image != null
                            ? MemoryImage(
                          base64Decode(base64image),
                        )
                            : null,
                        child: base64image == null ? Icon(Icons.add_a_photo) : null,
                      ),
                      SizedBox(height: 10),
                      Text(
                        namee, // Replace with actual name
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.bold
                        ),
                      ),
                      Text(
                        widget.email, // Replace with actual email
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w100
                        ),
                      ),
                    ],
                  ),
                ),
                ListTile(
                  leading: Icon(Icons.person),
                  title: Text('Profile'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => UserProfile(email: widget.email,)),
                    );
                  },
                ),

                ListTile(
                  leading: Icon(Icons.edit),
                  title: Text('Edit Profile'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => UserEditProfile(email: widget.email,)),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.history),
                  title: Text('Payment  History'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => PaymentHistory(email: widget.email,)),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.history),
                  title: Text('Booking  History'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => BookingHistory(email: widget.email,)),
                    );
                  },
                ),

                ListTile(
                  leading: Icon(Icons.feedback),
                  title: Text('Feedback'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FeebackPage()),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.call),
                  title: Text('Support'),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => Contactuspage()),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.logout, color: Colors.red),
                  title: Text('Logout', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                  onTap: () {
                    Navigator.pop(context); // Close the drawer first
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(builder: (context) => LoginOptions()),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        body: _widgetOptions.elementAt(_selectedIndex),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.blue[100],

          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home, color: Colors.white),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.assignment, color: Colors.white),
              label: 'Status',
            ),
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.history, color: Colors.white),
            //   label: 'History',
            // ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: Colors.white,
          onTap: _onItemTapped,
        ),
      ),
    );
  }
}
