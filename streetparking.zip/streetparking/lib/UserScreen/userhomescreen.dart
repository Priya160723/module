import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../urls.dart';
import 'ParkingDetails.dart';

class userhomescreen extends StatefulWidget {
  final String email;
  const userhomescreen({Key? key, required this.email}) : super(key: key);

  @override
  State<userhomescreen> createState() => _userhomescreenState();
}

class _userhomescreenState extends State<userhomescreen> {
  List<Map<String, dynamic>> parkingData = [];
  List<Map<String, dynamic>> filteredData = [];
  String searchQuery = '';
  String selectedLocation = '';

  @override
  void initState() {
    super.initState();
    fetchParkingStatus();
  }

  Future<void> fetchParkingStatus() async {
    final response = await http.post(
      Uri.parse('${Urls.ip}/Parkeasy/adminstatuspage.php'),
      body: jsonEncode({}),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        setState(() {
          parkingData = List<Map<String, dynamic>>.from(data['data']);
          filteredData = parkingData;
        });
      } else {
        print('Failed to fetch parking status: ${data['message']}');
      }
    } else {
      print('Error fetching parking status');
    }
  }

  void updateSearchResults(String query) {
    setState(() {
      searchQuery = query;
      filteredData = parkingData.where((parking) {
        final matchesLocation = selectedLocation.isEmpty ||
            parking['location'].toLowerCase() == selectedLocation.toLowerCase();
        final matchesName = parking['name'].toLowerCase().contains(query.toLowerCase());
        return matchesLocation && matchesName && parking['status'] == 'approved';
      }).toList();
    });
  }

  void updateLocationFilter(String location) {
    setState(() {
      selectedLocation = location;
      updateSearchResults(searchQuery);
    });
  }

  @override
  Widget build(BuildContext context) {
    final uniqueLocations = parkingData
        .map((parking) => parking['location'])
        .toSet()
        .toList();

    return Scaffold(

      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                TextField(
                  onChanged: updateSearchResults,
                  decoration: InputDecoration(

                    prefixIcon: Icon(Icons.search),
                    hintText: 'Search by name',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                DropdownButtonFormField<String>(

                  value: selectedLocation.isEmpty ? null : selectedLocation,
                  hint: Text('Filter by location'),
                  items: uniqueLocations.map((location) {
                    return DropdownMenuItem<String>(
                      value: location,
                      child: Text(location),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      updateLocationFilter(newValue);
                    }
                  },
                  decoration: InputDecoration(

                    floatingLabelStyle: TextStyle(fontWeight: FontWeight.bold),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                )


              ],
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: fetchParkingStatus,
              child: filteredData.isEmpty
                  ? Center(child: Text('No parking locations found'))
                  : ListView.builder(
                itemCount: filteredData.length,
                itemBuilder: (context, index) {
                  final parking = filteredData[index];
                  final imageBytes = base64Decode(parking['image']);

                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ParkingDetailsPage(
                            parking: parking,
                            email: widget.email,
                          ),
                        ),
                      );
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 10),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Container(
                            height: 200,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: MemoryImage(imageBytes),
                                fit: BoxFit.cover,
                              ),
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            parking['name'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text('Cost: ${parking['cost']} /hour'),
                          //Text('Floors: ${parking['floors']}'),
                          Text('Email: ${parking['email']}',style: TextStyle(fontWeight: FontWeight.bold),),
                         // Text('Location: ${parking['location']}'),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
