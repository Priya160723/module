
// String ip="http://192.168.206.113:80";



class Urls {
  static String ip = "http://192.168.1.6:8080";
}

//192.168.124.89
