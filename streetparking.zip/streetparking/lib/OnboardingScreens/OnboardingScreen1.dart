import 'package:flutter/material.dart';
import 'package:streetparking/Colors.dart';

import '../LoginOptions.dart';

class Onboarding1Screen extends StatefulWidget {
  const Onboarding1Screen({Key? key}) : super(key: key);

  @override
  State<Onboarding1Screen> createState() => _Onboarding1ScreenState();
}

class _Onboarding1ScreenState extends State<Onboarding1Screen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
  }

  void _skip() {
    Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => LoginOptions()));
  }

  void _continue() {
    Navigator.of(context).push(
        MaterialPageRoute(builder: (context) => LoginOptions()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.lightBlueAccent,
              _currentPage == 0
                  ? Colors.pinkAccent
                  : _currentPage == 1
                  ? Colors.pinkAccent.withOpacity(0.5)
                  : Colors.pinkAccent.withOpacity(0.4)
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Stack(
          children: [
            PageView(
              controller: _pageController,
              onPageChanged: _onPageChanged,
              children: [
                _buildPageContent(
                    'Welcome to Parkeasy ', 'Check for fare and book a spot', 'assets/car1.png'),
                _buildPageContent(
                    'Easy Parking', 'Choose your parking spot at finger tips', 'assets/bike2.png'),
                _buildPageContent(
                    'Find Your Spot', 'Experience the Hassel Free Parking ', 'assets/car2.png'),
              ],
            ),
            if (_currentPage < 2)
              Positioned(
                top: 40.0,
                right: 20.0,
                child: TextButton(
                  onPressed: _skip,
                  child: Text(
                    'Skip',
                    style: TextStyle(
                      fontSize: 18.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            Positioned(
              bottom: 30.0,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(3, (index) {
                  return AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    height: 12.0,
                    width: _currentPage == index ? 12.0 : 10.0,
                    decoration: BoxDecoration(
                      color: _currentPage == index
                          ? Colors.white
                          : Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(6.0),
                    ),
                  );
                }),
              ),
            ),
            if (_currentPage == 2)
              Positioned(
                bottom: 30.0,
                left: 0,
                right: 0,
                child: Center(
                  child: Container(
                    width: 250,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _continue,
                      child: Text(
                        'Continue',
                        style: TextStyle(fontSize: 18.0),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(horizontal: 50.0, vertical: 10.0),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPageContent(String title, String description, String imagePath) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              imagePath,
              width: 380.0,
              height: 300.0,
            ),
            SizedBox(height: 20.0),
            Text(
              title,
              style: TextStyle(
                fontSize: 28.0,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20.0),
            Text(
              description,
              style: TextStyle(
                fontSize: 18.0,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}